# Learn k6 Series
Complete Playlist is available [here](https://www.youtube.com/playlist?list=PLJ9A48W0kpRJKmVeurt7ltKfrOdr8ZBdt).
