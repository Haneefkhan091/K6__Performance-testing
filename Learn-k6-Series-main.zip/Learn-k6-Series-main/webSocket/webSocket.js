import http from "k6/http";
import sleep from "k6/sleep";

export default function() {

    const url = 'ws://echo.websocket.org';


}